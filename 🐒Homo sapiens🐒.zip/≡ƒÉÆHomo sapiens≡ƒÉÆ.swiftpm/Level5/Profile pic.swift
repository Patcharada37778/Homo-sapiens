import SwiftUI
import AVFoundation

struct ProfilePictureView: View {
    class AudioPlayer {
        var audioPlayer: AVAudioPlayer?
        var currentSongIndex = 0
        let songs = ["Reward"]
        
        func playAudio() {
            guard let song = Bundle.main.url(forResource: songs[currentSongIndex], withExtension: "mp3") else { 
                print("Audio file not found")
                return 
            }
            
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: song)
                audioPlayer?.volume = 0.5 // Adjust the volume here (0.0 to 1.0)
                audioPlayer?.play()
                print("Audio playing...")
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
        
        func stopAudio() {
            audioPlayer?.stop()
        }
    }
    
    
    @State private var audioPlayer = AudioPlayer()
    @Binding var image: Image?
    @State private var isActive: Bool = false
    @Binding var isViewThreePresented: Bool
    let synthesizer = AVSpeechSynthesizer()
    let textToSpeak = "HOMO SAPIENS SAPIENS"
    
    var body: some View {
        ZStack {
            Image("Forest")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            ZStack {
                RoundedRectangle(cornerRadius: 20.0)
                    .frame(width: 900, height: 580)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                Text("HOMO SAPIENS SAPIENS")
                    .font(.custom("Menlo", size: 40))
                    .offset(x: 80, y: -220)
                Text("(Modern Human)")
                    .font(.custom("Menlo", size: 36))
                    .offset(x: -15, y: -165)
                Text("120 000 years ago")
                    .font(.custom("Menlo", size: 24))
                    .offset(x: -35, y: -100)
                    .foregroundColor(.blue)
                Text("Height : 1.70 m\nWeight : 70 kg")
                    .font(.custom("Menlo", size: 30))
                    .offset(x: -20, y: -15)
                Text("(Estimate from average modern human)")
                    .font(.custom("Menlo", size: 22))
                    .offset(x: 80, y: 40)
                Text("Varied subsistence strategies, including hunting, gathering,\nand later, agriculture. Developed complex social structures,\nenabling collaboration for food production and protection.")
                    .font(.custom("Menlo", size: 22))
                    .offset(x: 10, y: 135)
                Button(action: speakButtonTapped) {
                    Image(systemName: "speaker.wave.2.circle.fill")
                        .padding()
                        .foregroundColor(.blue)
                        .font(.custom("Menlo", size: 60))
                }
                .offset(x:370, y:-225)
                Text("⭐️⭐️⭐️⭐️⭐️")
                    .font(.custom("Menlo", size: 52))
                    .offset(x: -280, y: 220)
                if let selectedImage = image {
                    ZStack {
                        Rectangle()
                            .fill(Color.blue)
                            .frame(width: 200, height: 300)
                            .offset(x:-300, y: -100)
                            .overlay(
                                selectedImage
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 200, height: 300)
                                    .clipShape(Rectangle())
                                    .offset(x:-300, y: -100)
                            )
                    }
                    .padding()
                    .onTapGesture {
                        isViewThreePresented.toggle()
                    }
                }
                Button(action: {
                    isActive = true
                }) {
                    Text("End the journey")
                        .font(.custom("Menlo", size: 22))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .offset(x: 300, y: 230)
            }
            .onAppear {
                self.audioPlayer.playAudio()
            }
            .fullScreenCover(isPresented: $isActive) {
                Ending()
            }
        }
    }
    func speakButtonTapped() {
        let speechUtterance = AVSpeechUtterance(string: textToSpeak)
        speechUtterance.rate = 0.4  // Adjust the rate to make it slower
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")  // Choose a female voice
        
        synthesizer.speak(speechUtterance)
    }
}

