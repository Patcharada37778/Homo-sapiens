import SwiftUI

struct Selfie: View {
    @State private var image: Image?
    @State private var showCamera: Bool = false
    @State private var isViewThreePresented: Bool = false
    
    var body: some View {
        ZStack {
            Image("Forest")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 20.0)
                    .frame(width: 1150, height: 140)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                    .offset(y: 317)
                
                Text("We have come to the end of our journey.\nLet's take a selfie for our great memories exploring the world!")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                    .padding()
                    .offset(x: 0, y: 317)
            }
            if isViewThreePresented {
                ProfilePictureView(image: $image, isViewThreePresented: $isViewThreePresented)
                    .fullScreenCover(isPresented: $isViewThreePresented, content: {
                        ProfilePictureView(image: $image, isViewThreePresented: $isViewThreePresented)
                    })
            } else {
                Button(action: {
                    self.showCamera.toggle()
                }) {
                    Image(systemName: "camera.circle.fill")
                        .resizable()
                        .frame(width: 150, height: 150)
                        .foregroundColor(.yellow)
                }
                .fullScreenCover(isPresented: $showCamera) {
                    CameraPicker(image: self.$image, isViewTwoPresented: self.$isViewThreePresented)
                }
            }
        }
    }
}



struct CameraPicker: UIViewControllerRepresentable {
    @Binding var image: Image?
    @Binding var isViewTwoPresented: Bool
    @Environment(\.presentationMode) private var presentationMode
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        @Binding var image: Image?
        @Binding var isViewTwoPresented: Bool
        @Binding var presentationMode: PresentationMode
        
        init(image: Binding<Image?>, isViewTwoPresented: Binding<Bool>, presentationMode: Binding<PresentationMode>) {
            _image = image
            _isViewTwoPresented = isViewTwoPresented
            _presentationMode = presentationMode
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                image = Image(uiImage: uiImage)
                isViewTwoPresented.toggle()
            }
            
            presentationMode.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            presentationMode.dismiss()
        }
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(image: $image, isViewTwoPresented: $isViewTwoPresented, presentationMode: presentationMode)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.sourceType = .camera
            picker.cameraDevice = .front // Set the camera device to front camera
            picker.delegate = context.coordinator
        }
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
}


