import SwiftUI
import AVKit

struct Loading: View {
    @State private var backgroundImageName = "1"
    @State private var counter = 1
    @State private var isPresentingSecondView = false
    @State private var player: AVPlayer?
    
    var body: some View {
        VStack {
            if let player = player {
                VideoPlayer(player: player)
                    .onAppear {
                        player.play()
                    }
                    .onDisappear {
                        player.pause() // Pause the video when leaving the view
                    }
            } else {
                Image(backgroundImageName)
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
            }
        }
        .onAppear {
            let _ = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { timer in
                counter += 1
                backgroundImageName = "\(counter % 6 == 0 ? 6 : counter % 6)"
                
                if counter == 18 && player == nil {
                    if let url = Bundle.main.url(forResource: "Video", withExtension: "mp4") {
                        player = AVPlayer(url: url)
                        player?.play()
                    }
                }
            }
        }
        .onChange(of: player?.rate, perform: { rate in
            if rate == 0 {
                // Video playback has completed
                isPresentingSecondView = true
            }
        })
        .fullScreenCover(isPresented: $isPresentingSecondView) {
            Intro1()
        }
    }
}
