import SwiftUI
import AVFoundation

struct Ending: View {
    class AudioPlayer {
        var audioPlayer: AVAudioPlayer?
        var currentSongIndex = 0
        let songs = ["Reward"]
        
        func playAudio() {
            guard let song = Bundle.main.url(forResource: songs[currentSongIndex], withExtension: "mp3") else { 
                print("Audio file not found")
                return 
            }
            
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: song)
                audioPlayer?.volume = 0.5 // Adjust the volume here (0.0 to 1.0)
                audioPlayer?.play()
                print("Audio playing...")
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
        
        func stopAudio() {
            audioPlayer?.stop()
        }
    }
    
    
    @State private var audioPlayer = AudioPlayer()
    @State private var isActive: Bool = false
    
    var body: some View {
        ZStack {
                Image("Ending")
                    .resizable()
                    .frame(width: 1000, height: 700)
                    .offset(y:-50)
            Image("Name")
                .resizable()
                .frame(width: 1000, height: 700)
                .offset(y:-50)
                }
        .onAppear {
            self.audioPlayer.playAudio()
        }
    }
}
