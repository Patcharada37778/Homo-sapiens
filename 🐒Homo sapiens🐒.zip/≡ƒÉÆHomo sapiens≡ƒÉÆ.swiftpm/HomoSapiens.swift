import SwiftUI

@main
struct HomoSapiens: App {
    var body: some Scene {
        WindowGroup {
            Loading()
        }
    }
}
