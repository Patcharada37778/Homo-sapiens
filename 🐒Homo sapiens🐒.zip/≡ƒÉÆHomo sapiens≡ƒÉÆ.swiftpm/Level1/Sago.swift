import SwiftUI

struct Sago: View {
    @State private var isActive: Bool = false
    @State private var sagoWiggles = false
    var body: some View {
        ZStack {
            Image("Forest")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 20.0)
                    .frame(width: 1150, height: 140)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                    .offset(y: 317)
                
                Text("Check out this intriguing plant! It resembles weird,\nbut there's a twist. Let's take a closer look.\n(Click on the plant and uncover the mistery!)")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                    .padding()
                    .offset(x: 0, y: 317)
                
                Button(action: {
                    isActive = true
                }) {
                    Image("SagoPalm")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 400) // Adjust the size as needed
                        .padding()
                        .rotationEffect(.degrees(sagoWiggles ? 0 : 2.5))
                        .rotation3DEffect(
                            .degrees(5),axis: (x: 0, y: -5, z: 0))
                        .animation(Animation.easeInOut(duration: 0.15).repeatForever(autoreverses: true))
                        .onAppear(){
                            sagoWiggles.toggle()
                        }
                }
                .offset(x: 0, y: 20) // Adjust the offset as needed
            }
        }
        .fullScreenCover(isPresented: $isActive) {
            SagoInfo()
        }
    }
}
