import SwiftUI

struct LevelOne: View {
    var body: some View {
        NavigationView {
            GameView(size: 4, tileSize: 100)
                .navigationBarBackButtonHidden(true)
        }
    }
}

struct GameView: View {
    let size: Int
    let tileSize: CGFloat
    
    @State private var tiles: [Int] = Array(1...15).shuffled() + [0]
    @State private var showAlert = false
    @State private var solveButtonUsed = false
    @State private var isHominidInfoPresented = false
    
    var body: some View {
        VStack(spacing: 0) {
            Text("Tap on a tile to move")
                .font(.custom("Menlo", size: 18))
                .offset(y:-30)
            ForEach(0..<size, id: \.self) { row in
                HStack(spacing: 0) {
                    ForEach(0..<size, id: \.self) { column in
                        TileView(
                            number: tiles[row * size + column],
                            size: tileSize
                        ) {
                            self.tapTile(at: (row, column))
                        }
                    }
                }
            }
            
            // "Solve" button
            Button(action: {
                tiles = Array(1...15) + [0]
                solveButtonUsed = true
                showAlert = true
            }) {
                Text("Surrender")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.pink)
                    .bold()
            } 
            .offset(y: 30)
            .fullScreenCover(isPresented: $isHominidInfoPresented) {
                HominidInfo()
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text(solveButtonUsed ? "Appreciate Your Efforts" : "Congratulations"),
                message: Text(solveButtonUsed ? "You solved the puzzle using the Surrender button. Great effort!" : "You solved the puzzle by playing. Well done!"),
                dismissButton: .default(Text("Next")) {
                    isHominidInfoPresented = true
                }
            )
        }
        .onAppear(perform: {
            while !isSolvable(size: size, tiles: tiles) {
                tiles.shuffle()
            }
        })
    }
    
    func tapTile(at position: (row: Int, column: Int)) {
        let index = position.row * size + position.column
        
        if canMoveTile(at: position) {
            let emptyIndex = tiles.firstIndex(of: 0)!
            tiles.swapAt(index, emptyIndex)
            
            if tiles == Array(1...15) + [0] {
                showAlert = true
            }
        }
    }
    
    func canMoveTile(at position: (row: Int, column: Int)) -> Bool {
        let emptyIndex = tiles.firstIndex(of: 0)!
        let emptyPosition = (emptyIndex / size, emptyIndex % size)
        return abs(emptyPosition.0 - position.0) + abs(emptyPosition.1 - position.1) == 1
    }
    
    func isSolvable(size: Int, tiles: [Int]) -> Bool {
        var inversions = 0
        for i in 0..<tiles.count {
            if tiles[i] == 0 { continue }
            for j in (i+1)..<tiles.count {
                if tiles[j] == 0 { continue }
                if tiles[j] < tiles[i] {
                    inversions += 1
                }
            }
        }
        return inversions % 2 == 0
    }
}

struct TileView: View {
    let number: Int
    let size: CGFloat
    let onTap: () -> Void
    
    var body: some View {
        let imageNames: [String] = {
            let baseName = "image"
            let range = 1...15
            return range.map { "\(baseName)\($0)" }
        }()
        
        let tileText = Text("\(number)")
            .font(.system(size: size * 0.4))
        
        return ZStack {
            if number != 0 && number <= 15 {
                Color.white
                Image(imageNames[number - 1])
                    .resizable()
                    .scaledToFill()
                    .frame(width: size, height: size)
                tileText
            } else {
                tileText
                    .foregroundColor(Color.white)
            }
        }
        .frame(width: size, height: size)
        .onTapGesture {
            onTap()
        }
    }
}


