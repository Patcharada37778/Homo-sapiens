import SwiftUI
import AVFoundation
struct HominidInfo: View {
    class AudioPlayer {
        var audioPlayer: AVAudioPlayer?
        var currentSongIndex = 0
        let songs = ["Reward"]
        
        func playAudio() {
            guard let song = Bundle.main.url(forResource: songs[currentSongIndex], withExtension: "mp3") else { 
                print("Audio file not found")
                return 
            }
            
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: song)
                audioPlayer?.volume = 0.5 // Adjust the volume here (0.0 to 1.0)
                audioPlayer?.play()
                print("Audio playing...")
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
        
        func stopAudio() {
            audioPlayer?.stop()
        }
    }
    
    
    @State private var audioPlayer = AudioPlayer()
    @State private var isActive: Bool = false
    let synthesizer = AVSpeechSynthesizer()
    let textToSpeak = "AUSTRALOPITHECUS"
    var body: some View {
        ZStack {
            Image("Forest")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 20.0)
                    .frame(width: 900, height: 580)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                Image("Hominid")
                    .resizable()
                    .frame(width: 250, height: 300)
                    .offset(x: -270,y: -88)
                Text("AUSTRALOPITHECUS")
                    .font(.custom("Menlo", size: 48))
                    .offset(x: 100, y: -220)
                Text("(Hominid)")
                    .font(.custom("Menlo", size: 36))
                    .offset(x: -40, y: -165)
                Text("3 500 000/ 2 500 000 years ago")
                    .font(.custom("Menlo", size: 24))
                    .offset(x: 88, y: -100)
                    .foregroundColor(.blue)
                Text("Height : 1.10 m\nWeight : 40 kg")
                    .font(.custom("Menlo", size: 30))
                    .offset(x: 8, y: -10)
                Text("Likely engaged in foraging and scaving for plant foods\nand small animals. Lived in wooded areas, using both\nbipedalism and climbing skills")
                    .font(.custom("Menlo", size: 22))
                    .offset(x: 10, y: 135)
                Button(action: speakButtonTapped) {
                    Image(systemName: "speaker.wave.2.circle.fill")
                        .padding()
                        .foregroundColor(.blue)
                        .font(.custom("Menlo", size: 60))
                }
                .offset(x: 370, y: -225)
                
                Text("⭐️")
                    .font(.custom("Menlo", size: 52))
                    .offset(x: -340, y: 220)
                
            }
            Button(action: {
                isActive = true
            })
            {
                Text("CONTINUE")
                    .font(.custom("Menlo", size: 22))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .offset(x: 350, y: 230)
        }
        .onAppear {
            self.audioPlayer.playAudio()
        }
        .fullScreenCover(isPresented: $isActive) {
            IntroTwo()
        }
    
        
    }
    func speakButtonTapped() {
        let speechUtterance = AVSpeechUtterance(string: textToSpeak)
        speechUtterance.rate = 0.3
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        synthesizer.speak(speechUtterance)
    }
}
