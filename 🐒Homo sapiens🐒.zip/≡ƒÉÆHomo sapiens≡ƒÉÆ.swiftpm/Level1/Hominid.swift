import SwiftUI

struct Hominid: View {
    @State private var isActive: Bool = false
    @State private var sagoWiggles = false
    
    var body: some View {
        ZStack {
            Image("Forest")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                Button(action: {
                    isActive = true
                }) {
                    Image("HominidPic")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 400) // Adjust the size as needed
                        .padding()
                        .rotationEffect(.degrees(sagoWiggles ? 0 : 2.5))
                        .rotation3DEffect(
                            .degrees(5),axis: (x: 0, y: -5, z: 0))
                        .animation(Animation.easeInOut(duration: 0.15).repeatForever(autoreverses: true))
                        .onAppear(){
                            sagoWiggles.toggle()
                        }
                }
                RoundedRectangle(cornerRadius: 25.0)
                    .frame(width: 1150, height: 200)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                    .offset(y: 293)
                
                Text("Look, I think I spotted someone over there! Let's get closer\nfor a better look... Oh, wait, why does he seem a bit off?\nLet's investigate and see if we can fix things up.")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)
                    .offset(x: 0, y: 290)
            }
        }
        .fullScreenCover(isPresented: $isActive) {
            LevelOne()
        }
    }
}
