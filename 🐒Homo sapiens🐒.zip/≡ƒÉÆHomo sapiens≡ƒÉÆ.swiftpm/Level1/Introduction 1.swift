import SwiftUI
import AVFoundation

struct Intro1: View {
    class AudioPlayer {
        var audioPlayer: AVAudioPlayer?
        var currentSongIndex = 0
        let songs = ["Audio"]
        
        func playAudio() {
            guard let song = Bundle.main.url(forResource: songs[currentSongIndex], withExtension: "m4a") else { 
                print("Audio file not found")
                return 
            }
            
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: song)
                audioPlayer?.volume = 0.5 // Adjust the volume here (0.0 to 1.0)
                audioPlayer?.play()
                print("Audio playing...")
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
        
        func stopAudio() {
            audioPlayer?.stop()
        }
    }
    
    @State private var isActive: Bool = false
    @State private var audioPlayer = AudioPlayer()
    
    var body: some View {
        ZStack {
            Image("Forest")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 25.0)
                    .frame(width: 1150, height: 200)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                    .offset(y: 293)
                
                Text("Welcome to a time 3 million years ago! Step into the ancient woodlands,\nthe home of our early relatives, the hominids. Join us as we discover\ntheir world full of mystery, challenges, and fascinating stories.\nLet's journey back and connect with the roots of our family tree.")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .offset(x: 45, y: 290)
            }
            
            Button(action: {
                isActive = true
            }) {
                Text("Let's Go")
                    .font(.custom("Menlo", size: 22))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .offset(x: 485, y: 340)
        }
        .onAppear {
            self.audioPlayer.playAudio()
        }
        .fullScreenCover(isPresented: $isActive) {
            Sago()
        }
    }
}

