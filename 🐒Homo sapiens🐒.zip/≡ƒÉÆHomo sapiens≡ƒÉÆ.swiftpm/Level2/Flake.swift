import SwiftUI

struct Flake: View {
    @State private var isActive: Bool = false
    @State private var currentIndex = 0
    @State private var showBlueButton = false
    @State private var position: CGFloat = -20
    @State private var loopCount = 0
    @State private var opacity: Double = 1.0
    
    let contentData: [(image: String, text: String)] = [
        ("Stone", "Swipe the rock to the left to strike."),
        ("OneStrike", "Strike again to make it sharper."),
        ("TwoStrike", "Strike two times for the final touch."),
        ("ThreeStrike", "Last strike!"),
        // Add more images and texts as needed
    ]
    
    var body: some View {
        ZStack {
            Image(contentData[currentIndex].image)
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 400)
                .offset(x: -200)
            
            Text(contentData[currentIndex].text)
                .font(.title)
                .padding()
                .offset(x: 300, y: -100)
            
            Spacer()
            Text("👆")
                .font(.system(size: 100))
                .offset(x: position)
                .opacity(opacity)
            
                .onAppear {
                    animateEmoji()
                }
                .onChange(of: loopCount) { count in
                    if count < 3 {
                        animateEmoji()
                        loopCount += 5
                    }
                }
            
            if showBlueButton {
                Button(action: {
                    isActive = true   
                }) {
                    Text("Let's Go")
                        .font(.custom("Menlo", size: 22))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .offset(x: 485, y: 340)
                .fullScreenCover(isPresented: $isActive) {
                    ToolInfo()
                }
            }
        }
        .gesture(DragGesture(minimumDistance: 20)
            .onEnded { value in
                if value.translation.width < 0 {
                    // Swiped to the left
                    if currentIndex < contentData.count - 1 {
                        currentIndex += 1
                        showBlueButton = false
                    } else {
                        showBlueButton = true
                    }
                } 
            }
        )
        .edgesIgnoringSafeArea(.all) 
    }
    private func animateEmoji() {
        withAnimation(Animation.linear(duration: 1)) {
            position = -350
        }
        
        withAnimation(Animation.easeOut(duration: 0.5).delay(1.5)) {
            opacity = 0.0
        }
        
        withAnimation(Animation.easeOut(duration: 0.5).delay(2)) {
            position = -200
            opacity = 0
        }
    }
}

