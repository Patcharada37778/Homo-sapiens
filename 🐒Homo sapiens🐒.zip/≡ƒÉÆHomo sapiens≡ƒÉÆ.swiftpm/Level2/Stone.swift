import SwiftUI

struct Stone: View {
    @State private var showAlert = false
    @State private var showAlertt = false
    @State private var isActive: Bool = false
    
    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all) // Ensure the background fills the screen
            
            ZStack {
                Spacer()
                
                ZStack {
                    Spacer()
                    
                    Button(action: {
                        showAlert.toggle()
                    }) {
                        Image("SmallStone")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .padding()
                    }
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Too Small!"), message: Text("Please try to choose again"), dismissButton: .default(Text("OK")))
                    }
                    .offset(x: -210)
                    
                    Spacer()
                    
                    Button(action: {
                        showAlertt.toggle()
                    }) {
                        Image("FlatStone")
                            .resizable()
                            .frame(width: 200, height: 200)
                            .padding()
                    }
                    .alert(isPresented: $showAlertt) {
                        Alert(title: Text("Too Thin!"), message: Text("Please try to choose again"), dismissButton: .default(Text("OK")))
                    }
                    .offset(x: 250)
                    
                    Spacer()
                }
                
                Spacer()
                
                Button(action: {
                    isActive = true
                }) {
                    Image("Stone")
                        .resizable()
                        .frame(width: 250, height: 250)
                        .padding()
                }
                
                Spacer()
            }
        }
        .fullScreenCover(isPresented: $isActive) {
            StoneInfo()
        }
    }
}
