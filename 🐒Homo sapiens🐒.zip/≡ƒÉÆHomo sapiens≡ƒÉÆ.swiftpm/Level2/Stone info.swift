import SwiftUI
import AVFoundation

struct StoneInfo: View {
    class AudioPlayer {
        var audioPlayer: AVAudioPlayer?
        var currentSongIndex = 0
        let songs = ["Reward"]
        
        func playAudio() {
            guard let song = Bundle.main.url(forResource: songs[currentSongIndex], withExtension: "mp3") else { 
                print("Audio file not found")
                return 
            }
            
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: song)
                audioPlayer?.volume = 0.5 // Adjust the volume here (0.0 to 1.0)
                audioPlayer?.play()
                print("Audio playing...")
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
        
        func stopAudio() {
            audioPlayer?.stop()
        }
    }
    
    
    @State private var audioPlayer = AudioPlayer()
    @State private var isActive: Bool = false
    let synthesizer = AVSpeechSynthesizer()
    let textToSpeak = "Bidirectional Core"
    
    var body: some View {
        ZStack {
            Image("Grassland")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 20.0)
                    .frame(width: 900, height: 580)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                Image("Bidirectional Core")
                    .resizable()
                    .frame(width: 200, height: 300)
                    .offset(x: -290,y: -88)
                Text("Bidirectional Core")
                    .font(.custom("Menlo", size: 44))
                    .offset(x: 90, y: -220)
                Text("Late Holocene")
                    .font(.custom("Menlo", size: 24))
                    .offset(x: -53, y: -140)
                    .foregroundColor(.blue)
                Text("Location: New South Wales\nMaterial:  Metasedimentary")
                    .font(.custom("Menlo", size: 30))
                    .offset(x: 88, y: -20)
                
                Text("This metasedimentary bidirectional core is from the Northern\nTablelands of New South Wales. The core was reduced from\nplatforms located at either end of the stone.")
                    .font(.custom("Menlo", size: 22))
                    .offset(x: 6, y: 135)
                Button(action: speakButtonTapped) {
                    Image(systemName: "speaker.wave.2.circle.fill")
                        .padding()
                        .foregroundColor(.blue)
                        .font(.custom("Menlo", size: 60))
                }
                .offset(x: 370, y: -225)
                Text("⭐️⭐️")
                    .font(.custom("Menlo", size: 52))
                    .offset(x: -320, y: 220)
                Button(action: {
                    isActive = true
                }) {
                    Text("CONTINUE")
                        .font(.custom("Menlo", size: 22))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .offset(x: 350, y: 230)
            }
            .navigationBarBackButtonHidden(true)
        }
        .onAppear {
            self.audioPlayer.playAudio()
        }
        .fullScreenCover(isPresented: $isActive) {
            Flake()
                .navigationBarBackButtonHidden(true)
        }
    }
    func speakButtonTapped() {
        let speechUtterance = AVSpeechUtterance(string: textToSpeak)
        speechUtterance.rate = 0.3  // Adjust the rate to make it slower
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")  // Choose a female voice
        
        synthesizer.speak(speechUtterance)
    }
}
