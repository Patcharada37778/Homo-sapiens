import SwiftUI

struct IntroTwo: View {
    @State private var isActive: Bool = false
    
    var body: some View {
        ZStack {
            Image("Grassland")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 25.0)
                    .frame(width: 1150, height: 200)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                    .offset(y: 293)
                
                Text("Today's a great day for hunting, but I don't have any tools.\nCan you help me create one?")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .offset(x: 45, y: 290)
            }
            
            Button(action: {
                isActive = true
            }) {
                Text("Let's Go")
                    .font(.custom("Menlo", size: 22))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .offset(x: 485, y: 340)
        }
        .fullScreenCover(isPresented: $isActive) {
            Stone()
        }
    }
}
