import SwiftUI

struct Rock: View {
    @State private var swipeCount = 0
    @State private var yOffset: CGFloat = 0
    @State private var isThirdViewActive = false
    @State private var timer: Timer?
    
    var body: some View {
        ZStack {
            Text("swipe the rock on the")
                .font(.custom("Menlo", size: 24))
                .foregroundColor(.black)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .offset(x: 100, y: -100)
            Text("RIGHT")
                .font(.custom("Menlo", size: 36))
                .fontWeight(.bold)
                .foregroundColor(.purple)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .offset(x: 430, y: -103)
            Text("UP-DOWN-RELEASE")
                .font(.custom("Menlo", size: 50))
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .offset(x: 90, y: -20)
        
            Image("StoneOne")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 300, height: 300)
                .padding()
                .offset(x: 170)
            
            Spacer()
            
            Image("StoneTwo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 300, height: 300)
                .padding()
                .offset(x:335, y: yOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            yOffset = value.translation.height
                            startTimer() // Start the timer when dragging
                        }
                        .onEnded { value in
                            if yOffset > 50 {
                                swipeCount += 1
                                checkSwipeCount()
                            } else if yOffset < -50 {
                                swipeCount -= 1
                                checkSwipeCount()
                            }
                            
                            withAnimation {
                                yOffset = 0
                            }
                        }
                )
        }
        .fullScreenCover(isPresented: $isThirdViewActive) {
            Fire()
        }
        .padding()
        .onDisappear {
            timer?.invalidate()
            timer = nil
        }
    }
    
    private func checkSwipeCount() {
        if swipeCount >= 10 {
            isThirdViewActive = true
        } else if swipeCount < 0 {
            swipeCount = 0
        }
    }
    
    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { _ in
            if !isThirdViewActive {
                // Change view or perform any action after 5 seconds of continuous swiping
                isThirdViewActive = true
            }
        }
    }
}
