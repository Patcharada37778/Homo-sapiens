import SwiftUI

struct Log: View {
    @State private var isSecondViewActive = false
    
    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all) // Fill the entire screen with white background
            
            ZStack {
                Text("Now, envision a stack of logs\nready to turn into a cozy fire.")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .offset(x: 50, y: -40)
                
                Image("Log")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 300, height: 300)
                    .padding()
                    .offset(x: 250)
                
                
                Button("Create Fire 🔥") {
                    isSecondViewActive.toggle()
                }
                .padding()
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
                .offset(x:-300, y: 80) // Adjusted offset
                
                Spacer() // Fill remaining space
            }
        }
        .fullScreenCover(isPresented: $isSecondViewActive) {
            Rock()
        }
    }
}
