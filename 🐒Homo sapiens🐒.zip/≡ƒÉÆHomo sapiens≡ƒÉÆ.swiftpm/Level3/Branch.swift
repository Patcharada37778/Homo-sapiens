import SwiftUI

struct Branch: View {
    @State private var tapCount = 0
    @State private var isActive: Bool = false
    
    var countdown: Int {
        return 7 - tapCount
    }
    
    var body: some View {
        ZStack {
            Text("Tap the branch")
                .font(.custom("Menlo", size: 24))
                .foregroundColor(.black)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .offset(x: 150, y: -100)
            Text("\(countdown) times")
                .font(.custom("Menlo", size: 50))
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .offset(x: 150, y: -32)
            Text("to cut it into 8 pieces")
                .font(.custom("Menlo", size: 24))
                .foregroundColor(.black)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .offset(x: 110, y: 30)
            
            Button(action: {
                if tapCount < 6 {
                    tapCount += 1
                } else {
                    isActive = true
                }
            }) {
                Image("Branch")
                    .resizable()
            }
            .aspectRatio(contentMode: .fill)
            .frame(width: 250, height: 250)
            .offset(x: 250)
        }
        .fullScreenCover(isPresented: $isActive) {
            Log()
        }
    }
}
