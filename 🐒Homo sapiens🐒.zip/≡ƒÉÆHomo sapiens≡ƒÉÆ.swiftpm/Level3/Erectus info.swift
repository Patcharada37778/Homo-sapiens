import SwiftUI
import AVFoundation
struct ErectusInfo: View {
    class AudioPlayer {
        var audioPlayer: AVAudioPlayer?
        var currentSongIndex = 0
        let songs = ["Reward"]
        
        func playAudio() {
            guard let song = Bundle.main.url(forResource: songs[currentSongIndex], withExtension: "mp3") else { 
                print("Audio file not found")
                return 
            }
            
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: song)
                audioPlayer?.volume = 0.5 // Adjust the volume here (0.0 to 1.0)
                audioPlayer?.play()
                print("Audio playing...")
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
        
        func stopAudio() {
            audioPlayer?.stop()
        }
    }
    
    
    @State private var audioPlayer = AudioPlayer()
    @State private var isActive: Bool = false
    let synthesizer = AVSpeechSynthesizer()
    let textToSpeak = "HOMO ERECTUS"
    
    var body: some View {
        ZStack {
            Image("Savannah")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 20.0)
                    .frame(width: 900, height: 580)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                Image("Erectus")
                    .resizable()
                    .frame(width: 200, height: 300)
                    .offset(x: -290,y: -88)
                Text("HOMO ERECTUS")
                    .font(.custom("Menlo", size: 48))
                    .offset(x: 30, y: -220)
                Text("1 900 000/ 400 000 years ago")
                    .font(.custom("Menlo", size: 24))
                    .offset(x: 60, y: -140)
                    .foregroundColor(.blue)
                Text("Height : 1.60 m\nWeight :60 kg")
                    .font(.custom("Menlo", size: 30))
                    .offset(x: -5, y: -20)
                
                Text("Engaged in hunting and gathering, with an emphasis on\nmeat consumption. Likely used fire for cooking, providing\nwarmth, and protection")
                    .font(.custom("Menlo", size: 22))
                    .offset(x: 6, y: 135)
                Button(action: speakButtonTapped) {
                    Image(systemName: "speaker.wave.2.circle.fill")
                        .padding()
                        .foregroundColor(.blue)
                        .font(.custom("Menlo", size: 60))
                }
                .offset(x: 250,y: -225)
                Text("⭐️⭐️⭐️")
                    .font(.custom("Menlo", size: 52))
                    .offset(x: -310, y: 220)
                Button(action: {
                    isActive = true
                }) {
                    Text("CONTINUE")
                        .font(.custom("Menlo", size: 22))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .offset(x: 350, y: 230)
            }
            .navigationBarBackButtonHidden(true)
        }
        .onAppear {
            self.audioPlayer.playAudio()
        }
        .fullScreenCover(isPresented: $isActive) {
            IntroFour()
                .navigationBarBackButtonHidden(true)
        }
    }
    func speakButtonTapped() {
        let speechUtterance = AVSpeechUtterance(string: textToSpeak)
        speechUtterance.rate = 0.3 // Adjust the rate to make it slower
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")  // Choose a female voice
        
        synthesizer.speak(speechUtterance)
    }
}

