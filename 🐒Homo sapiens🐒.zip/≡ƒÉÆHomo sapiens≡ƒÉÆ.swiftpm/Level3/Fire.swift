import SwiftUI

struct Fire: View {
    @State private var isActive: Bool = false
    var body: some View {
        ZStack {
            Text("Bask in the warmth of your achievement.\nAh, the crackling flames dance,\nand you’re the fire magician.\nWarmth achieved, adventure completed.\nThanks for your fire-making prowess! 🔥")
                .font(.custom("Menlo", size: 24))
                .foregroundColor(.black)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .offset(x: 50, y:-70)
            
            Image("LogFire")
                .resizable()
                .scaledToFit()
                .frame(width: 350, height: 350)
                .offset(x: 300)
            
            // Add content for the third view as needed
            Button(action: {
                isActive = true
            }) {
                Text("Let's Go")
                    .font(.custom("Menlo", size: 22))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .offset(x: -300, y: 60)
        }
        .fullScreenCover(isPresented: $isActive) {
            ErectusInfo()
        }
        
    }
}
