import SwiftUI
import Speech
import AVFoundation

struct SpeechToText: View {
    @State private var isRecording = false
    @State private var recognizedText = ""
    @State private var audioPlayer: AVAudioPlayer?
    @State private var showDrawingScreen = false
    private let audioEngine = AVAudioEngine()
    var body: some View {
        ZStack {
            Image("CaveArt")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 20.0)
                    .frame(width: 900, height: 580)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                VStack {
                    Text("Tap the MIC!")
                        .font(.custom("Menlo", size: 50))
                        .bold()
                        .foregroundColor(.blue)
                        .padding()
                    Text("Say: Let's go hunt together!")
                        .font(.custom("Menlo", size: 22))
                        
                    
                    Button(action: {
                        if isRecording {
                            stopRecording()
                            playAudio()
                            showDrawingScreen = true
                        } else {
                            startRecording()
                        }
                    }) {
                        Image(systemName: isRecording ? "hand.thumbsup.circle.fill" : "mic.circle.fill")
                            .font(.system(size: 100))
                            .foregroundColor(isRecording ? Color.yellow : Color.blue)
                            .frame(width: 200, height: 200)
                        
                            
                    }
                    .padding()
                    
                    Text("Recognized Text: \(recognizedText)")
                        .font(.custom("Menlo", size: 18))
                        
                }
                .onAppear {
                    requestSpeechAuthorization()
                }
                .fullScreenCover(isPresented: $showDrawingScreen) {
                    EarlyCave()
                }
            }
        }
    }

    
    private func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            if authStatus == .authorized {
                print("Speech recognition authorization granted.")
            } else {
                print("Speech recognition authorization denied.")
            }
        }
    }
    
    private func startRecording() {
        isRecording = true
        recognizedText = ""
        
        let recognizer = SFSpeechRecognizer()
        let request = SFSpeechAudioBufferRecognitionRequest()
        
        do {
            try recognizer?.recognitionTask(with: request) { [self] (result, error) in
                if let result = result {
                    let transcript = result.bestTranscription.formattedString
                    self.recognizedText = transcript
                }
            }
            
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            
            let inputNode = audioEngine.inputNode
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                request.append(buffer)
            }
            
            audioEngine.prepare()
            try audioEngine.start()
        } catch {
            print("Error starting recording: \(error.localizedDescription)")
        }
    }
    
    private func stopRecording() {
        isRecording = false
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
    }
    
    private func playAudio() {
        if let path = Bundle.main.path(forResource: "Gogo ", ofType: "m4a") {
            let url = URL(fileURLWithPath: path)
            
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.duckOthers, .mixWithOthers])
                try AVAudioSession.sharedInstance().setActive(true)
                
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
                print("Audio playback started successfully.")
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        } else {
            print("Audio file not found.")
        }
    }
}
