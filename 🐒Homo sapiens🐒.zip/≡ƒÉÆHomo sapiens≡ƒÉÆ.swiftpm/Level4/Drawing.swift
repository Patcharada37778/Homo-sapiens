import SwiftUI
import PencilKit

struct Line {
    var points: [CGPoint]
    var color: Color
}

struct Drawing: View {
    
    @State private var lines: [Line] = []
    @State private var selectedColor = Color.orange
    @State var isdraw = true
    @State var canvas = PKCanvasView()
    @State var type: PKInkingTool.InkType = .pen
    @State private var isActive: Bool = false
    
    var body: some View {
        HStack {
            ZStack(alignment: .center) {
                DrawingView(canvas: $canvas, isdraw: $isdraw, type: $type, color: $selectedColor, backgroundImage: UIImage(named: "Cave Paint"))
                Text(" let's coloring!")
                    .font(.custom("Menlo", size: 30))
                    .bold()
                    .foregroundColor(.blue)
                    .offset(x: -70, y: 260)
            }
            
            ZStack {
                Button(action: {
                    isdraw.toggle()
                }) {
                    Image(systemName: "eraser")
                }
                .foregroundColor(Color.blue)
                .offset(y:-100)
                .font(.title)
                
                Button(action: {
                    isdraw = true
                    type = .pencil
                }) {
                    Image(systemName: "pencil")
                }
                .foregroundColor(Color.blue)
                .offset(y:-50)
                .font(.title)
                
                Button(action: {
                    isdraw = true
                    type = .pen
                }) {
                    Image(systemName: "pencil.and.outline")
                }
                .foregroundColor(Color.blue)
                .offset(y:0)
                .font(.title)
                
                Button(action: {
                    isdraw = true
                    type = .marker
                }) {
                    Image(systemName: "highlighter")
                }
                .foregroundColor(Color.blue)
                .offset(y: 50)
                .font(.title)
                
                Button(action: {
                    isActive = true
                }) {
                    Text("Done")
                        .font(.custom("Menlo", size: 22))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .offset(y: 130) // Adjusted offset value
            }
            .fullScreenCover(isPresented: $isActive) {
                CaveArt()
            }
            
            ZStack {
                VStack {
                    
                    ForEach([Color.red, .orange, .yellow, .green, .blue, .purple, .black], id: \.self) { color in
                        colorButton(color: color)
                            .padding()
                    }
                }
            }
            .gesture(
                DragGesture(minimumDistance: 0, coordinateSpace: .local)
                    .onChanged({ value in
                        let position = value.location
                        
                        if value.translation == .zero {
                            lines.append(Line(points: [position], color: selectedColor))
                        } else {
                            guard let lastIdx = lines.indices.last else {
                                return
                            }
                            
                            lines[lastIdx].points.append(position)
                        }
                    })
            )
        }
    }
    
    @ViewBuilder
    func colorButton(color: Color) -> some View {
        Button {
            selectedColor = color
        } label: {
            Image(systemName: "circle.fill")
                .font(.largeTitle)
                .foregroundColor(color)
            
        }
    }
    
    
    struct DrawingView: UIViewRepresentable {
        @Binding var canvas: PKCanvasView
        @Binding var isdraw: Bool
        @Binding var type: PKInkingTool.InkType
        @Binding var color: Color
        var backgroundImage: UIImage? // Add this property for the background image
        
        var ink: PKInkingTool {
            PKInkingTool(type, color: UIColor(color))
        }
        
        let eraser = PKEraserTool(.bitmap)
        
        func makeUIView(context: Context) -> PKCanvasView {
            canvas.drawingPolicy = .anyInput
            canvas.tool = isdraw ? ink : eraser
            return canvas
        }
        
        func updateUIView(_ uiView: PKCanvasView, context: Context) {
            uiView.tool = isdraw ? ink : eraser
            
            // Set the background image if available
            if let backgroundImage = backgroundImage {
                uiView.backgroundColor = UIColor(patternImage: backgroundImage)
            }
        }
    }
}
