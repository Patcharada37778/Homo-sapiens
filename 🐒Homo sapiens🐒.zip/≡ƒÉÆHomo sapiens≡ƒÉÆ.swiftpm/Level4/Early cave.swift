import SwiftUI

struct EarlyCave: View {
    @State private var isActive: Bool = false
    
    var body: some View {
        ZStack {
            Image("CaveArt")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            Color.black
                .opacity(0.6)
                .edgesIgnoringSafeArea(.all)
            
            ZStack {
                RoundedRectangle(cornerRadius: 25.0)
                    .frame(width: 1150, height: 200)
                    .foregroundColor(.white)
                    .opacity(0.9)
                    .padding()
                    .offset(y: 293)
                
                Text("Whew, today was quite an adventure! Let's jot down\nsome notes in our diaries for our future family to read.")
                    .font(.custom("Menlo", size: 24))
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .offset(x: 45, y: 290)
            }
            
            Button(action: {
                isActive = true
            }) {
                Text("Let's Go")
                    .font(.custom("Menlo", size: 22))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .offset(x: 485, y: 340)
        }
        .fullScreenCover(isPresented: $isActive) {
            Drawing()
        }
    }
}

